//package instrument;

import soot.*;
import soot.jimple.*;
import soot.jimple.internal.JGotoStmt;
import soot.util.Chain;

import java.util.Iterator;
import java.util.Map;

public class GotoInstrumenter extends BodyTransformer {
    static SootClass  counterClass;
    static SootMethod recordGoto;
//    protected static SootMethod counterV;


    static {
//  TO DO: 注册 Counter 以及 recordGoto
//  
    }

    @Override
    protected synchronized void internalTransform(Body body, String s, Map<String, String> map) {
//  TO DO: 在合适的位置插装Counter中的代码
    }
}
