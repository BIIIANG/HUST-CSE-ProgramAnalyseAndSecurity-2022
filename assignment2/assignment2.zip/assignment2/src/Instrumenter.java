//package instrument;

import soot.*;
import soot.jimple.*;
import soot.jimple.internal.JGotoStmt;

import soot.toolkits.graph.*;
import soot.util.Chain;

import java.util.*;

public class Instrumenter extends BodyTransformer {
	
	// TO DO  add necessary fields
    static {
	// TO DO add necessary logic
    }

    @Override
    protected synchronized void internalTransform(Body body, String s, Map<String, String> map) {
	// TO DO add necessary logic
    }

	// TO DO you can add necessary member functions
}
