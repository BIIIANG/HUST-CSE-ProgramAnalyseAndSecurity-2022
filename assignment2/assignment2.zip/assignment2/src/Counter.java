//package src;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.*;

public class Counter {


	// TO DO  Add necessary fileds

    static {
//      hook addShutdownHook，类似于junit的@AfterClass
        Runtime.getRuntime().addShutdownHook(new Thread(() -> {
            try {
                Counter.generateReport();
            } catch (IOException e) {
                System.err.println("Could not write report to file: " + e);
            }
        }));
    }
	
	// Add necessary memboer functions
}
